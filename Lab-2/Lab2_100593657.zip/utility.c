/*
Authors
Sohaib Mohiuddin
Umar Riaz
Matthew Bernard
Vidit Vyas
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <string.h>
#include "utility.h"
